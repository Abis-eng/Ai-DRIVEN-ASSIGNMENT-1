import { useNavigate } from "react-router-dom";
import {
  Bell,
  ChevronDown,
  CircleHelp,
  LayoutDashboard,
  PackageCheck,
  Search,
  ShoppingCart,
  Sparkles,
  Utensils,
  UtensilsCrossed,
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

import "./0641a16c-3edd-4d7c-b662-f2e9a512cc5d.css";
import "./AI-Customer-Support.screen.css";

export default function AICustomerSupport() {
  const navigate = useNavigate();
  return (
    <div data-appearance="light">
      <div className="bg-background text-foreground w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="bg-background text-foreground min-h-screen">
          <aside className="bg-sidebar border-y-border border-r border-r-border border-l-border flex fixed z-20 inset-y-0 left-0 px-4 py-6 flex-col w-64">
            <div className="flex px-3 items-center gap-3">
              <div className="rounded-xl bg-primary text-primary-foreground flex justify-center items-center size-10">
                <UtensilsCrossed className="size-5" />
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-foreground text-xl tracking-tight">
                  FoodHub
                </span>
                <span className="font-semibold uppercase rounded-full bg-accent text-primary text-[10px] tracking-wide px-2 py-0.5">
                  AI
                </span>
              </div>
            </div>
            <nav
              aria-label="Main navigation"
              className="flex mt-10 flex-col flex-1 gap-2"
            >
              <a
                href="#dashboard"
                className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                onClick={() => navigate("/customer-dashboard")}
              >
                <LayoutDashboard className="size-5" />
                <span>Dashboard</span>
              </a>
              <a
                href="#food-menu"
                className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                onClick={() => navigate("/food-menu")}
              >
                <Utensils className="size-5" />
                <span>Food Menu</span>
              </a>
              <a
                href="#shopping-cart"
                className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                onClick={() => navigate("/shopping-cart")}
              >
                <ShoppingCart className="size-5" />
                <span>Shopping Cart</span>
              </a>
              <a
                href="#order-tracking"
                className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                onClick={() => navigate("/order-tracking")}
              >
                <PackageCheck className="size-5" />
                <span>Order Tracking</span>
              </a>
              <a
                href="#ai-support"
                aria-current="page"
                className="font-semibold rounded-xl bg-primary text-primary-foreground text-sm flex px-4 py-3 items-center gap-3"
              >
                <Sparkles className="size-5" />
                <span>AI Support</span>
              </a>
            </nav>
            <a
              href="#help-support"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
            >
              <CircleHelp className="size-5" />
              <span>{`Help & Support`}</span>
            </a>
          </aside>
          <main className="ml-64 min-h-screen">
            <header className="bg-background border-t-border border-r-border border-b border-b-border border-l-border flex px-8 justify-between items-center h-20">
              <div>
                <p className="text-muted-foreground text-sm">Workspace</p>
                <h1 className="font-bold text-foreground text-2xl tracking-tight">
                  AI Customer Support
                </h1>
              </div>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  aria-label="Search"
                  className="rounded-xl text-muted-foreground flex justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                >
                  <Search className="size-5" />
                </button>
                <button
                  type="button"
                  aria-label="Notifications"
                  className="rounded-xl text-muted-foreground flex relative justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
                >
                  <Bell className="size-5" />
                  <span className="rounded-full bg-primary absolute top-2 right-2 size-2" />
                </button>
                <div className="bg-border w-px h-8" />
                <div
                  aria-label="Customer account: Ayesha Khan"
                  className="flex items-center gap-3"
                >
                  <div className="font-semibold rounded-full bg-primary text-primary-foreground text-sm flex justify-center items-center size-10">
                    AK
                  </div>
                  <div className="text-left hidden md:block">
                    <p className="font-semibold text-foreground text-sm">
                      Ayesha Khan
                    </p>
                    <p className="text-muted-foreground text-xs">Customer</p>
                  </div>
                  <ChevronDown className="text-muted-foreground size-4" />
                </div>
              </div>
            </header>
            <div className="p-8">
              <div className="mb-6">
                <h2 className="font-bold text-foreground text-2xl tracking-tight">
                  How can we help today?
                </h2>
                <p className="text-muted-foreground text-sm mt-2">
                  FoodHub AI is here for orders, menus and delivery questions.
                </p>
              </div>
              <div className="grid gap-6 grid-cols-[minmax(0,1fr)_20rem]">
                <Card className="flex flex-col h-[680px] overflow-hidden">
                  <CardHeader className="border-t-border border-r-border border-b border-b-border border-l-border flex px-6 py-5 flex-row justify-between items-center">
                    <div className="flex items-center gap-3">
                      <Avatar className="rounded-xl bg-primary text-primary-foreground size-10">
                        <AvatarFallback className="rounded-xl bg-primary text-primary-foreground">
                          <Sparkles className="size-5" />
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-base">
                          FoodHub AI Assistant
                        </CardTitle>
                        <Badge className="bg-accent text-accent-foreground mt-1">
                          Online
                        </Badge>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      className="text-muted-foreground text-sm"
                    >
                      Clear chat
                    </Button>
                  </CardHeader>
                  <CardContent className="flex p-0 flex-col flex-1 min-h-0">
                    <div className="p-6 flex-1 overflow-y-auto">
                      <div className="flex">
                        <div className="rounded-xl text-sm leading-6 px-4 py-3 max-w-3/4">
                          Hi Ayesha! I’m the FoodHub AI Assistant. I can help
                          with your order, menu, offers, and delivery questions.
                        </div>
                      </div>
                      <div className="flex">
                        <div className="rounded-xl text-sm leading-6 px-4 py-3 max-w-3/4">
                          Where is my order #FH-20842?
                        </div>
                      </div>
                      <div className="flex">
                        <div className="rounded-xl text-sm leading-6 px-4 py-3 max-w-3/4">
                          Your order is being prepared at Spice Route Kitchen.
                          It should arrive in about 35–45 minutes.
                        </div>
                      </div>
                    </div>
                    <div className="border-x-border border-t border-t-border border-b-border p-6">
                      <div className="flex items-center gap-3">
                        <Input
                          placeholder="Type your message..."
                          defaultValue=""
                          className="h-11"
                        />
                        <Button className="px-5 h-11">Send</Button>
                      </div>
                      <p className="text-muted-foreground text-xs mt-3">
                        I’m ready when you are.
                      </p>
                    </div>
                  </CardContent>
                </Card>
                <div className="flex flex-col gap-6">
                  <Card>
                    <CardHeader className="px-6 py-5">
                      <CardTitle className="text-lg">
                        Suggested questions
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="flex px-6 pb-6 flex-col gap-3">
                      <Button
                        variant="outline"
                        className="justify-start w-full"
                      >
                        Where is my order?
                      </Button>
                      <Button
                        variant="outline"
                        className="justify-start w-full"
                      >
                        What food items are available?
                      </Button>
                      <Button
                        variant="outline"
                        className="justify-start w-full"
                      >
                        What are today’s special offers?
                      </Button>
                      <Button
                        variant="outline"
                        className="justify-start w-full"
                      >
                        How long will delivery take?
                      </Button>
                      <Button
                        variant="outline"
                        className="justify-start w-full"
                      >
                        What payment methods are available?
                      </Button>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="px-6 py-5">
                      <CardTitle className="text-base">
                        Popular help topics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="flex px-6 pb-6 flex-wrap gap-2">
                      <Badge variant="secondary">Delivery</Badge>
                      <Badge variant="secondary">Refunds</Badge>
                      <Badge variant="secondary">Account</Badge>
                      <p className="text-muted-foreground text-xs mt-2 w-full">
                        Typically replies in under a minute.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
