import { useNavigate } from "react-router-dom";
import {
  Bell,
  ChevronDown,
  CircleHelp,
  LayoutDashboard,
  PackageCheck,
  Search,
  ShoppingCart,
  Sparkles,
  Star,
  Utensils,
  UtensilsCrossed,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

import "./0641a16c-3edd-4d7c-b662-f2e9a512cc5d.css";
import "./Food-Menu.screen.css";

export default function FoodMenu() {
  const navigate = useNavigate();
  return (
    <div data-appearance="light">
      <div className="bg-background text-foreground w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <aside className="bg-sidebar border-y-border border-r border-r-border border-l-border flex fixed z-20 inset-y-0 left-0 px-4 py-6 flex-col w-64">
          <div className="flex px-3 items-center gap-3">
            <div className="rounded-xl bg-primary text-primary-foreground flex justify-center items-center size-10">
              <UtensilsCrossed className="size-5" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-foreground text-xl tracking-tight">
                FoodHub
              </span>
              <span className="font-semibold uppercase rounded-full bg-accent text-primary text-[10px] tracking-wide px-2 py-0.5">
                AI
              </span>
            </div>
          </div>
          <nav
            aria-label="Main navigation"
            className="flex mt-10 flex-col flex-1 gap-2"
          >
            <a
              href="#dashboard"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/customer-dashboard")}
            >
              <LayoutDashboard className="size-5" />
              <span>Dashboard</span>
            </a>
            <a
              href="#food-menu"
              aria-current="page"
              className="font-semibold rounded-xl bg-primary text-primary-foreground text-sm flex px-4 py-3 items-center gap-3"
            >
              <Utensils className="size-5" />
              <span>Food Menu</span>
            </a>
            <a
              href="#shopping-cart"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/shopping-cart")}
            >
              <ShoppingCart className="size-5" />
              <span>Shopping Cart</span>
            </a>
            <a
              href="#order-tracking"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/order-tracking")}
            >
              <PackageCheck className="size-5" />
              <span>Order Tracking</span>
            </a>
            <a
              href="#ai-support"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/ai-customer-support")}
            >
              <Sparkles className="size-5" />
              <span>AI Support</span>
            </a>
          </nav>
          <a
            href="#help-support"
            className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          >
            <CircleHelp className="size-5" />
            <span>{`Help & Support`}</span>
          </a>
        </aside>
        <main className="ml-64 min-h-screen">
          <header className="bg-background border-t-border border-r-border border-b border-b-border border-l-border flex px-8 justify-between items-center h-20">
            <div>
              <p className="text-muted-foreground text-sm">Workspace</p>
              <h1 className="font-bold text-foreground text-2xl tracking-tight">
                Food Menu
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                type="button"
                aria-label="Search"
                className="rounded-xl text-muted-foreground flex justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Search className="size-5" />
              </button>
              <button
                type="button"
                aria-label="Notifications"
                className="rounded-xl text-muted-foreground flex relative justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Bell className="size-5" />
                <span className="rounded-full bg-primary absolute top-2 right-2 size-2" />
              </button>
              <div className="bg-border w-px h-8" />
              <div
                aria-label="Customer account: Ayesha Khan"
                className="flex items-center gap-3"
              >
                <div className="font-semibold rounded-full bg-primary text-primary-foreground text-sm flex justify-center items-center size-10">
                  AK
                </div>
                <div className="text-left hidden md:block">
                  <p className="font-semibold text-foreground text-sm">
                    Ayesha Khan
                  </p>
                  <p className="text-muted-foreground text-xs">Customer</p>
                </div>
                <ChevronDown className="text-muted-foreground size-4" />
              </div>
            </div>
          </header>
          <section className="p-8">
            <div className="flex justify-between items-end gap-6">
              <div>
                <h2 className="font-bold text-foreground text-3xl tracking-tight">
                  Find your next favorite meal
                </h2>
                <p className="text-muted-foreground mt-2">
                  Made fresh by local kitchens, delivered to your door.
                </p>
              </div>
            </div>
            <div className="flex mt-8 items-start gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search dishes, restaurants or ingredients"
                  defaultValue=""
                  className="rounded-xl bg-card px-4 h-12"
                />
                <p className="text-muted-foreground text-sm mt-2">
                  Showing 24 dishes from 8 restaurants
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                className="rounded-xl px-5 h-12"
                onClick={() => navigate("/shopping-cart")}
              >
                <ShoppingCart className="size-4" />
                <span>Cart</span>
                <span className="font-semibold">0</span>
              </Button>
            </div>
            <Tabs defaultValue="All" className="mt-8">
              <TabsList className="rounded-xl bg-muted p-1 h-11">
                <TabsTrigger value="All" className="rounded-lg px-5">
                  All
                </TabsTrigger>
                <TabsTrigger value="Burgers" className="rounded-lg px-5">
                  Burgers
                </TabsTrigger>
                <TabsTrigger value="Pizza" className="rounded-lg px-5">
                  Pizza
                </TabsTrigger>
                <TabsTrigger value="Pakistani" className="rounded-lg px-5">
                  Pakistani
                </TabsTrigger>
                <TabsTrigger value="Drinks" className="rounded-lg px-5">
                  Drinks
                </TabsTrigger>
                <TabsTrigger value="Desserts" className="rounded-lg px-5">
                  Desserts
                </TabsTrigger>
              </TabsList>
            </Tabs>
            <section className="mt-10">
              <h3 className="font-bold text-foreground text-xl tracking-tight">
                Popular right now
              </h3>
              <div className="grid mt-5 gap-6 grid-cols-4">
                <Card className="transition-shadow shadow-xs rounded-xl bg-card border-border overflow-hidden hover:shadow-md">
                  <div className="aspect-[8/5] overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1551782450-a2132b4ba21d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwd2l0aCUyMGZyaWVzJTIwcmVzdGF1cmFudCUyMGZvb2QlMjBwaG90b2dyYXBoeXxlbnwxfDB8fHwxNzkzOTU4OTEzfDA&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Classic Zinger Burger"
                      data-photoid="uVPV_nV17Tw"
                      data-authorname="sk"
                      data-authorurl="https://unsplash.com/@rollelflex_graphy726"
                      data-blurhash="LD9P}*xs0hRRr?IqSf-m58NJ%K$z"
                      className="transition-transform size-full object-cover hover:scale-105"
                    />
                  </div>
                  <div className="flex p-4 flex-col gap-3">
                    <div className="flex justify-between items-center">
                      <Badge className="bg-destructive/10 text-destructive">
                        Spicy
                      </Badge>
                      <span className="font-medium text-foreground text-sm flex items-center gap-1">
                        <Star className="fill-primary text-primary size-4" />
                        4.8
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">
                        Classic Zinger Burger
                      </h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Crispy chicken, fresh lettuce and signature sauce.
                      </p>
                    </div>
                    <div className="flex justify-between items-center gap-3">
                      <span className="font-bold text-foreground">PKR 650</span>
                      <Button type="button" className="rounded-lg">
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </Card>
                <Card className="transition-shadow shadow-xs rounded-xl bg-card border-border overflow-hidden hover:shadow-md">
                  <div className="aspect-[8/5] overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1611915365928-565c527a0590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxwZXBwZXJvbmklMjBwaXp6YSUyMHNsaWNlZCUyMHJlc3RhdXJhbnQlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxM3ww&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Pepperoni Pizza"
                      data-photoid="XLmhRnV8yuc"
                      data-authorname="Tamas Pap"
                      data-authorurl="https://unsplash.com/@tamasp"
                      data-blurhash="L9Ra5G^}#Wxsq|Fcwf1z#AS2WCWC"
                      className="transition-transform size-full object-cover hover:scale-105"
                    />
                  </div>
                  <div className="flex p-4 flex-col gap-3">
                    <div className="flex justify-between items-center">
                      <Badge className="bg-destructive/10 text-destructive">
                        Spicy
                      </Badge>
                      <span className="font-medium text-foreground text-sm flex items-center gap-1">
                        <Star className="fill-primary text-primary size-4" />
                        4.9
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">
                        Pepperoni Pizza
                      </h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Loaded with pepperoni, mozzarella and rich tomato sauce.
                      </p>
                    </div>
                    <div className="flex justify-between items-center gap-3">
                      <span className="font-bold text-foreground">
                        PKR 1,450
                      </span>
                      <Button type="button" className="rounded-lg">
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </Card>
                <Card className="transition-shadow shadow-xs rounded-xl bg-card border-border overflow-hidden hover:shadow-md">
                  <div className="aspect-[8/5] overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1630851840633-f96999247032?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYmlyeWFuaSUyMGJvd2wlMjBQYWtpc3RhbmklMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxMnww&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Chicken Biryani"
                      data-photoid="2hpTXgfy6pg"
                      data-authorname="Raman"
                      data-authorurl="https://unsplash.com/@potofgold07"
                      data-blurhash="LIC6Mv-p0gNzx]R*RP%2I]NHr;$~"
                      className="transition-transform size-full object-cover hover:scale-105"
                    />
                  </div>
                  <div className="flex p-4 flex-col gap-3">
                    <div className="flex justify-between items-center">
                      <Badge className="bg-destructive/10 text-destructive">
                        Spicy
                      </Badge>
                      <span className="font-medium text-foreground text-sm flex items-center gap-1">
                        <Star className="fill-primary text-primary size-4" />
                        4.7
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">
                        Chicken Biryani
                      </h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Fragrant basmati rice with tender chicken and aromatic
                        spices.
                      </p>
                    </div>
                    <div className="flex justify-between items-center gap-3">
                      <span className="font-bold text-foreground">PKR 520</span>
                      <Button type="button" className="rounded-lg">
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </Card>
                <Card className="transition-shadow shadow-xs rounded-xl bg-card border-border overflow-hidden hover:shadow-md">
                  <div className="aspect-[8/5] overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1541658016709-82535e94bc69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG1pbGtzaGFrZSUyMGRlc3NlcnQlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxMnww&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Mango Shake"
                      data-photoid="-xhCOgeoDSs"
                      data-authorname="Fatima Akram"
                      data-authorurl="https://unsplash.com/@fatimaakram"
                      data-blurhash="LgGj{eOD0}tQmkNGOsj?-.XTn%V["
                      className="transition-transform size-full object-cover hover:scale-105"
                    />
                  </div>
                  <div className="flex p-4 flex-col gap-3">
                    <div className="flex justify-between items-center">
                      <Badge className="bg-secondary text-secondary-foreground">
                        Vegetarian
                      </Badge>
                      <span className="font-medium text-foreground text-sm flex items-center gap-1">
                        <Star className="fill-primary text-primary size-4" />
                        4.6
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">
                        Mango Shake
                      </h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Creamy seasonal mango blended with chilled milk.
                      </p>
                    </div>
                    <div className="flex justify-between items-center gap-3">
                      <span className="font-bold text-foreground">PKR 380</span>
                      <Button type="button" className="rounded-lg">
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            </section>
            <section className="mt-10">
              <h3 className="font-bold text-foreground text-xl tracking-tight">
                Featured combos
              </h3>
              <div className="grid mt-5 gap-6 grid-cols-2">
                <Card className="transition-shadow shadow-xs rounded-xl bg-card border-border flex overflow-hidden hover:shadow-md">
                  <div className="w-2/5 overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1551782450-a2132b4ba21d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwd2l0aCUyMGZyaWVzJTIwcmVzdGF1cmFudCUyMGZvb2QlMjBwaG90b2dyYXBoeXxlbnwxfDB8fHwxNzkzOTU4OTEzfDA&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Family Feast burger and pizza imagery"
                      data-photoid="uVPV_nV17Tw"
                      data-authorname="sk"
                      data-authorurl="https://unsplash.com/@rollelflex_graphy726"
                      data-blurhash="LD9P}*xs0hRRr?IqSf-m58NJ%K$z"
                      className="size-full object-cover"
                    />
                  </div>
                  <div className="flex p-5 flex-col justify-center flex-1 gap-3">
                    <div>
                      <h4 className="font-bold text-foreground text-lg">
                        Family Feast
                      </h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        A generous spread of burgers and pizza for everyone.
                      </p>
                    </div>
                    <div className="flex justify-between items-center gap-3">
                      <span className="font-bold text-foreground">
                        PKR 2,950
                      </span>
                      <Button type="button" className="rounded-lg">
                        Add combo
                      </Button>
                    </div>
                  </div>
                </Card>
                <Card className="transition-shadow shadow-xs rounded-xl bg-card border-border flex overflow-hidden hover:shadow-md">
                  <div className="w-2/5 overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1630851840633-f96999247032?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYmlyeWFuaSUyMGJvd2wlMjBQYWtpc3RhbmklMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxMnww&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Desi Comfort Box biryani imagery"
                      data-photoid="2hpTXgfy6pg"
                      data-authorname="Raman"
                      data-authorurl="https://unsplash.com/@potofgold07"
                      data-blurhash="LIC6Mv-p0gNzx]R*RP%2I]NHr;$~"
                      className="size-full object-cover"
                    />
                  </div>
                  <div className="flex p-5 flex-col justify-center flex-1 gap-3">
                    <div>
                      <h4 className="font-bold text-foreground text-lg">
                        Desi Comfort Box
                      </h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Homestyle biryani and comforting sides in one box.
                      </p>
                    </div>
                    <div className="flex justify-between items-center gap-3">
                      <span className="font-bold text-foreground">
                        PKR 1,250
                      </span>
                      <Button type="button" className="rounded-lg">
                        Add combo
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            </section>
          </section>
        </main>
      </div>
    </div>
  );
}
