import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Bell,
  Bike,
  Check,
  ChevronDown,
  CircleHelp,
  ClipboardCheck,
  CookingPot,
  LayoutDashboard,
  MapPin,
  MessageCircle,
  PackageCheck,
  Search,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  UserRound,
  Utensils,
  UtensilsCrossed,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import "./0641a16c-3edd-4d7c-b662-f2e9a512cc5d.css";
import "./Order-Tracking.screen.css";

export default function OrderTracking() {
  const navigate = useNavigate();
  return (
    <div data-appearance="light">
      <div className="bg-background text-foreground w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <aside className="bg-sidebar border-y-border border-r border-r-border border-l-border flex fixed z-20 inset-y-0 left-0 px-4 py-6 flex-col w-64">
          <div className="flex px-3 items-center gap-3">
            <div className="rounded-xl bg-primary text-primary-foreground flex justify-center items-center size-10">
              <UtensilsCrossed className="size-5" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-foreground text-xl tracking-tight">
                FoodHub
              </span>
              <span className="font-semibold uppercase rounded-full bg-accent text-primary text-[10px] tracking-wide px-2 py-0.5">
                AI
              </span>
            </div>
          </div>
          <nav
            aria-label="Main navigation"
            className="flex mt-10 flex-col flex-1 gap-2"
          >
            <a
              href="#dashboard"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/customer-dashboard")}
            >
              <LayoutDashboard className="size-5" />
              <span>Dashboard</span>
            </a>
            <a
              href="#food-menu"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/food-menu")}
            >
              <Utensils className="size-5" />
              <span>Food Menu</span>
            </a>
            <a
              href="#shopping-cart"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/shopping-cart")}
            >
              <ShoppingCart className="size-5" />
              <span>Shopping Cart</span>
            </a>
            <a
              href="#order-tracking"
              aria-current="page"
              className="font-semibold rounded-xl bg-primary text-primary-foreground text-sm flex px-4 py-3 items-center gap-3"
            >
              <PackageCheck className="size-5" />
              <span>Order Tracking</span>
            </a>
            <a
              href="#ai-support"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/ai-customer-support")}
            >
              <Sparkles className="size-5" />
              <span>AI Support</span>
            </a>
          </nav>
          <a
            href="#help-support"
            className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          >
            <CircleHelp className="size-5" />
            <span>{`Help & Support`}</span>
          </a>
        </aside>
        <main className="ml-64 min-h-screen">
          <header className="bg-background border-t-border border-r-border border-b border-b-border border-l-border flex px-8 justify-between items-center h-20">
            <div>
              <p className="text-muted-foreground text-sm">Workspace</p>
              <h1 className="font-bold text-foreground text-2xl tracking-tight">
                Order Tracking
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                type="button"
                aria-label="Search"
                className="rounded-xl text-muted-foreground flex justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Search className="size-5" />
              </button>
              <button
                type="button"
                aria-label="Notifications"
                className="rounded-xl text-muted-foreground flex relative justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Bell className="size-5" />
                <span className="rounded-full bg-primary absolute top-2 right-2 size-2" />
              </button>
              <div className="bg-border w-px h-8" />
              <div
                aria-label="Customer account: Ayesha Khan"
                className="flex items-center gap-3"
              >
                <div className="font-semibold rounded-full bg-primary text-primary-foreground text-sm flex justify-center items-center size-10">
                  AK
                </div>
                <div className="text-left hidden md:block">
                  <p className="font-semibold text-foreground text-sm">
                    Ayesha Khan
                  </p>
                  <p className="text-muted-foreground text-xs">Customer</p>
                </div>
                <ChevronDown className="text-muted-foreground size-4" />
              </div>
            </div>
          </header>
          <div className="mx-auto p-8 max-w-7xl">
            <a
              href="#shopping-cart"
              className="font-medium text-muted-foreground text-sm inline-flex mb-4 items-center gap-2 hover:text-foreground"
              onClick={() => navigate("/shopping-cart")}
            >
              <ArrowLeft className="size-4" />
              <span>My orders</span>
            </a>
            <div className="mb-8">
              <h2 className="font-bold text-foreground text-3xl tracking-tight">
                Track your order
              </h2>
              <p className="text-muted-foreground text-sm mt-2">
                We’ll keep you posted every step of the way.
              </p>
            </div>
            <Card className="bg-primary/10 border-primary/20 mb-8">
              <CardContent className="flex p-6 justify-between items-center gap-8">
                <div className="flex items-center gap-5">
                  <div className="rounded-xl bg-primary text-primary-foreground flex justify-center items-center size-12">
                    <PackageCheck className="size-6" />
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Order ID</p>
                    <p className="font-bold text-foreground text-lg mt-1">
                      #FH-20842
                    </p>
                  </div>
                </div>
                <div className="flex flex-col flex-1 gap-3 min-w-64">
                  <div className="flex justify-between items-center">
                    <Badge className="bg-primary text-primary-foreground">
                      Preparing food
                    </Badge>
                    <span className="font-semibold text-foreground text-sm">
                      Estimated delivery 35–45 min
                    </span>
                  </div>
                  <div className="rounded-full bg-background w-full h-2 overflow-hidden">
                    <div className="rounded-full bg-primary w-2/5 h-full" />
                  </div>
                  <p className="text-muted-foreground text-xs">
                    Arriving today, 12 June
                  </p>
                </div>
              </CardContent>
            </Card>
            <div className="grid gap-6 lg:grid-cols-3">
              <div className="flex flex-col gap-6 lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Delivery progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-2 grid-cols-5">
                      <div className="text-center flex relative flex-col items-center gap-3">
                        <div className="bg-primary absolute top-5 left-1/2 w-full h-0.5" />
                        <div className="rounded-full bg-primary text-primary-foreground flex relative z-10 justify-center items-center size-10">
                          <ClipboardCheck className="size-5" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground text-xs">
                            Order Confirmed
                          </p>
                          <p className="text-muted-foreground text-xs mt-1">
                            12:18 PM
                          </p>
                        </div>
                      </div>
                      <div className="text-center flex relative flex-col items-center gap-3">
                        <div className="bg-primary absolute top-5 left-1/2 w-full h-0.5" />
                        <div className="rounded-full bg-primary text-primary-foreground flex relative z-10 justify-center items-center size-10">
                          <CookingPot className="size-5" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground text-xs">
                            Preparing Food
                          </p>
                          <p className="text-muted-foreground text-xs mt-1">
                            12:24 PM
                          </p>
                        </div>
                      </div>
                      <div className="text-center flex relative flex-col items-center gap-3">
                        <div className="bg-border absolute top-5 left-1/2 w-full h-0.5" />
                        <div className="rounded-full bg-card text-primary border-2 border-primary flex relative z-10 justify-center items-center size-10">
                          <ShoppingBag className="size-5" />
                        </div>
                        <div>
                          <Badge
                            variant="outline"
                            className="text-primary border-primary mb-1"
                          >
                            Up next
                          </Badge>
                          <p className="font-semibold text-foreground text-xs">
                            Ready for Delivery
                          </p>
                          <p className="text-muted-foreground text-xs mt-1">
                            12:40 PM
                          </p>
                        </div>
                      </div>
                      <div className="text-center flex relative flex-col items-center gap-3">
                        <div className="bg-border absolute top-5 left-1/2 w-full h-0.5" />
                        <div className="rounded-full bg-muted text-muted-foreground flex relative z-10 justify-center items-center size-10">
                          <Bike className="size-5" />
                        </div>
                        <div>
                          <p className="font-semibold text-muted-foreground text-xs">
                            Out for Delivery
                          </p>
                          <p className="text-muted-foreground text-xs mt-1">
                            12:50 PM
                          </p>
                        </div>
                      </div>
                      <div className="text-center flex relative flex-col items-center gap-3">
                        <div className="rounded-full bg-muted text-muted-foreground flex relative z-10 justify-center items-center size-10">
                          <Check className="size-5" />
                        </div>
                        <div>
                          <p className="font-semibold text-muted-foreground text-xs">
                            Delivered
                          </p>
                          <p className="text-muted-foreground text-xs mt-1">
                            1:05 PM
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Order details</CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-4">
                    <div className="border-t-border border-r-border border-b border-b-border border-l-border flex pb-4 justify-between items-center">
                      <span className="text-foreground text-sm">
                        Classic Zinger Burger ×2
                      </span>
                      <span className="text-muted-foreground text-sm">
                        PKR 1,400
                      </span>
                    </div>
                    <div className="border-t-border border-r-border border-b border-b-border border-l-border flex pb-4 justify-between items-center">
                      <span className="text-foreground text-sm">
                        Pepperoni Pizza ×1
                      </span>
                      <span className="text-muted-foreground text-sm">
                        PKR 1,250
                      </span>
                    </div>
                    <div className="border-t-border border-r-border border-b border-b-border border-l-border flex pb-4 justify-between items-center">
                      <span className="text-foreground text-sm">
                        Mango Shake ×1
                      </span>
                      <span className="text-muted-foreground text-sm">
                        PKR 400
                      </span>
                    </div>
                    <div className="flex pt-1 justify-between items-center">
                      <span className="font-semibold text-foreground">
                        Total
                      </span>
                      <span className="font-bold text-foreground text-lg">
                        PKR 3,050
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <Card className="h-fit">
                <CardHeader>
                  <CardTitle>Spice Route Kitchen</CardTitle>
                  <CardDescription>Preparing your meal</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-6">
                  <div className="text-muted-foreground text-sm flex items-center gap-3">
                    <MapPin className="text-primary size-5" />
                    <span>Gulberg III, Lahore</span>
                  </div>
                  <div className="rounded-lg bg-muted border border-border relative h-40 overflow-hidden">
                    <div className="rounded-full bg-border absolute top-8 left-6 w-1 h-24" />
                    <div className="ring-4 ring-primary/20 rounded-full bg-primary absolute top-6 left-5 size-3" />
                    <div className="ring-4 ring-muted-foreground/20 rounded-full bg-muted-foreground absolute bottom-6 left-5 size-3" />
                    <div className="rotate-12 border-t-primary/60 border-r-primary/60 border-b-2 border-b-primary/60 border-l-primary/60 border-dashed absolute top-10 left-8 w-24 h-16" />
                    <div className="-rotate-12 rounded-xl bg-card/70 border border-border absolute top-8 right-8 w-24 h-16" />
                    <div className="rounded-xl bg-card/70 border border-border absolute right-8 bottom-7 w-20 h-10" />
                  </div>
                  <div className="rounded-lg bg-muted flex p-4 items-center gap-3">
                    <div className="rounded-full bg-accent text-primary flex justify-center items-center size-9">
                      <UserRound className="size-4" />
                    </div>
                    <p className="text-muted-foreground text-sm">
                      Your rider will appear here soon
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="w-fit"
                    onClick={() => navigate("/ai-customer-support")}
                  >
                    <MessageCircle className="size-4" />
                    <span>Get help</span>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
