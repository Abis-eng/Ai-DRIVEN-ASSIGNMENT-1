import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
// prettier-ignore
import CustomerDashboard from "./Customer-Dashboard.tsx";
import FoodMenu from "./Food-Menu.tsx";
import ShoppingCart from "./Shopping-Cart.tsx";
import OrderTracking from "./Order-Tracking.tsx";
import AICustomerSupport from "./AI-Customer-Support.tsx";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<CustomerDashboard />} />
        <Route path="/customer-dashboard" element={<CustomerDashboard />} />
        <Route path="/food-menu" element={<FoodMenu />} />
        <Route path="/shopping-cart" element={<ShoppingCart />} />
        <Route path="/order-tracking" element={<OrderTracking />} />
        <Route path="/ai-customer-support" element={<AICustomerSupport />} />
      </Routes>
    </BrowserRouter>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
