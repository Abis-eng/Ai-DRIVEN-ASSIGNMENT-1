import { useNavigate } from "react-router-dom";
import {
  Bell,
  ChevronDown,
  CircleHelp,
  CupSoda,
  IceCreamBowl,
  LayoutDashboard,
  LayoutGrid,
  PackageCheck,
  Pizza,
  Sandwich,
  Search,
  ShoppingCart,
  Sparkles,
  Star,
  Truck,
  Utensils,
  UtensilsCrossed,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

import { FallbackComponent } from "./CustomComponents";
import "./0641a16c-3edd-4d7c-b662-f2e9a512cc5d.css";
import "./Customer-Dashboard.screen.css";

export default function CustomerDashboard() {
  const navigate = useNavigate();
  return (
    <div data-appearance="light">
      <div className="bg-background text-foreground w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <aside className="bg-sidebar border-y-border border-r border-r-border border-l-border flex fixed z-20 inset-y-0 left-0 px-4 py-6 flex-col w-64">
          <div className="flex px-3 items-center gap-3">
            <div className="rounded-xl bg-primary text-primary-foreground flex justify-center items-center size-10">
              <UtensilsCrossed className="size-5" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-foreground text-xl tracking-tight">
                FoodHub
              </span>
              <span className="font-semibold uppercase rounded-full bg-accent text-primary text-[10px] tracking-wide px-2 py-0.5">
                AI
              </span>
            </div>
          </div>
          <nav
            aria-label="Main navigation"
            className="flex mt-10 flex-col flex-1 gap-2"
          >
            <a
              href="#dashboard"
              aria-current="page"
              className="font-semibold rounded-xl bg-primary text-primary-foreground text-sm flex px-4 py-3 items-center gap-3"
            >
              <LayoutDashboard className="size-5" />
              <span>Dashboard</span>
            </a>
            <a
              href="#food-menu"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/food-menu")}
            >
              <Utensils className="size-5" />
              <span>Food Menu</span>
            </a>
            <a
              href="#shopping-cart"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/shopping-cart")}
            >
              <ShoppingCart className="size-5" />
              <span>Shopping Cart</span>
            </a>
            <a
              href="#order-tracking"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/order-tracking")}
            >
              <PackageCheck className="size-5" />
              <span>Order Tracking</span>
            </a>
            <a
              href="#ai-support"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/ai-customer-support")}
            >
              <Sparkles className="size-5" />
              <span>AI Support</span>
            </a>
          </nav>
          <a
            href="#help-support"
            className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          >
            <CircleHelp className="size-5" />
            <span>{`Help & Support`}</span>
          </a>
        </aside>
        <main className="ml-64 min-h-screen">
          <header className="bg-background border-t-border border-r-border border-b border-b-border border-l-border flex px-8 justify-between items-center h-20">
            <div>
              <p className="text-muted-foreground text-sm">Workspace</p>
              <h1 className="font-bold text-foreground text-2xl tracking-tight">
                Dashboard
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                type="button"
                aria-label="Search"
                className="rounded-xl text-muted-foreground flex justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Search className="size-5" />
              </button>
              <button
                type="button"
                aria-label="Notifications"
                className="rounded-xl text-muted-foreground flex relative justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Bell className="size-5" />
                <span className="rounded-full bg-primary absolute top-2 right-2 size-2" />
              </button>
              <div className="bg-border w-px h-8" />
              <div
                aria-label="Customer account: Ayesha Khan"
                className="flex items-center gap-3"
              >
                <div className="font-semibold rounded-full bg-primary text-primary-foreground text-sm flex justify-center items-center size-10">
                  AK
                </div>
                <div className="text-left hidden md:block">
                  <p className="font-semibold text-foreground text-sm">
                    Ayesha Khan
                  </p>
                  <p className="text-muted-foreground text-xs">Customer</p>
                </div>
                <ChevronDown className="text-muted-foreground size-4" />
              </div>
            </div>
          </header>
          <div className="flex mx-auto p-8 flex-col gap-8 max-w-7xl">
            <div className="flex justify-between items-end">
              <div>
                <p className="text-muted-foreground text-sm">
                  Wednesday, 12 June
                </p>
                <h2 className="font-bold text-foreground text-3xl tracking-tight mt-2">
                  Good afternoon, Ayesha
                </h2>
                <p className="text-muted-foreground mt-2">
                  What are you craving today?
                </p>
              </div>
            </div>
            <Card className="shadow-sm rounded-xl bg-accent border-0 overflow-hidden">
              <div className="grid grid-cols-2 min-h-56">
                <div className="flex p-8 flex-col justify-center gap-4">
                  <Badge className="bg-primary/10 text-primary w-fit">
                    WELCOME20
                  </Badge>
                  <div>
                    <h3 className="font-bold text-accent-foreground text-2xl">
                      Get 20% off your first order
                    </h3>
                    <p className="text-accent-foreground/80 mt-2">
                      Fresh meals, delivered with a little extra joy.
                    </p>
                  </div>
                  <Button
                    className="w-fit"
                    onClick={() => navigate("/food-menu")}
                  >
                    Order Now
                  </Button>
                </div>
                <div className="p-4">
                  <img
                    src="https://images.unsplash.com/photo-1547573854-74d2a71d0826?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwZm9vZCUyMGZlYXN0JTIwdGFibGUlMjBvdmVyaGVhZCUyMHBob3RvZ3JhcGh5fGVufDF8MHx8fDE3OTM5NTg5MTN8MA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Warm spread of freshly prepared food"
                    data-photoid="Q_Moi2xjieU"
                    data-authorname="Stefan Vladimirov"
                    data-authorurl="https://unsplash.com/@skv_creates"
                    data-blurhash="LAC=-nV@0L-;RkR*bvE2E2WBaLxZ"
                    className="rounded-lg size-full object-cover"
                  />
                </div>
              </div>
            </Card>
            <section className="flex flex-col gap-4">
              <h3 className="font-bold text-xl tracking-tight">
                Browse by category
              </h3>
              <div className="grid gap-4 grid-cols-6">
                <Button
                  variant="secondary"
                  className="py-4 flex-col gap-2 h-auto"
                  onClick={() => navigate("/food-menu")}
                >
                  <LayoutGrid className="size-5" />
                  <span>All Food</span>
                </Button>
                <Button
                  variant="secondary"
                  className="py-4 flex-col gap-2 h-auto"
                  onClick={() => navigate("/food-menu")}
                >
                  <Sandwich className="size-5" />
                  <span>Burgers</span>
                </Button>
                <Button
                  variant="secondary"
                  className="py-4 flex-col gap-2 h-auto"
                  onClick={() => navigate("/food-menu")}
                >
                  <Pizza className="size-5" />
                  <span>Pizza</span>
                </Button>
                <Button
                  variant="secondary"
                  className="py-4 flex-col gap-2 h-auto"
                  onClick={() => navigate("/food-menu")}
                >
                  <FallbackComponent className="size-5" />
                  <span>Fast Food</span>
                </Button>
                <Button
                  variant="secondary"
                  className="py-4 flex-col gap-2 h-auto"
                  onClick={() => navigate("/food-menu")}
                >
                  <CupSoda className="size-5" />
                  <span>Drinks</span>
                </Button>
                <Button
                  variant="secondary"
                  className="py-4 flex-col gap-2 h-auto"
                  onClick={() => navigate("/food-menu")}
                >
                  <IceCreamBowl className="size-5" />
                  <span>Desserts</span>
                </Button>
              </div>
            </section>
            <section className="flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <h3 className="font-bold text-xl tracking-tight">
                  Featured for you
                </h3>
                <span className="text-muted-foreground text-sm">
                  Cart items: 0
                </span>
              </div>
              <div className="grid gap-6 grid-cols-4">
                <Card className="shadow-sm rounded-xl overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1551782450-a2132b4ba21d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwd2l0aCUyMGZyaWVzJTIwcmVzdGF1cmFudCUyMGZvb2QlMjBwaG90b2dyYXBoeXxlbnwxfDB8fHwxNzkzOTU4OTEzfDA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Zinger burger"
                    data-photoid="uVPV_nV17Tw"
                    data-authorname="sk"
                    data-authorurl="https://unsplash.com/@rollelflex_graphy726"
                    data-blurhash="LD9P}*xs0hRRr?IqSf-m58NJ%K$z"
                    className="w-full h-40 object-cover"
                  />
                  <div className="flex p-4 flex-col gap-3">
                    <div className="text-primary text-sm flex items-center gap-1">
                      <Star className="fill-primary size-4" />
                      4.8
                    </div>
                    <div>
                      <h4 className="font-semibold">Zinger Burger</h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Crispy chicken with fresh toppings
                      </p>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">PKR 650</span>
                      <Button size="sm">Add</Button>
                    </div>
                  </div>
                </Card>
                <Card className="shadow-sm rounded-xl overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1611915365928-565c527a0590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxwZXBwZXJvbmklMjBwaXp6YSUyMHNsaWNlZCUyMHJlc3RhdXJhbnQlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxM3ww&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Pepperoni pizza"
                    data-photoid="XLmhRnV8yuc"
                    data-authorname="Tamas Pap"
                    data-authorurl="https://unsplash.com/@tamasp"
                    data-blurhash="L9Ra5G^}#Wxsq|Fcwf1z#AS2WCWC"
                    className="w-full h-40 object-cover"
                  />
                  <div className="flex p-4 flex-col gap-3">
                    <div className="text-primary text-sm flex items-center gap-1">
                      <Star className="fill-primary size-4" />
                      4.9
                    </div>
                    <div>
                      <h4 className="font-semibold">Pepperoni Pizza</h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Loaded with pepperoni and mozzarella
                      </p>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">PKR 1,450</span>
                      <Button size="sm">Add</Button>
                    </div>
                  </div>
                </Card>
                <Card className="shadow-sm rounded-xl overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1630851840633-f96999247032?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYmlyeWFuaSUyMGJvd2wlMjBQYWtpc3RhbmklMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxMnww&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Chicken biryani"
                    data-photoid="2hpTXgfy6pg"
                    data-authorname="Raman"
                    data-authorurl="https://unsplash.com/@potofgold07"
                    data-blurhash="LIC6Mv-p0gNzx]R*RP%2I]NHr;$~"
                    className="w-full h-40 object-cover"
                  />
                  <div className="flex p-4 flex-col gap-3">
                    <div className="text-primary text-sm flex items-center gap-1">
                      <Star className="fill-primary size-4" />
                      4.7
                    </div>
                    <div>
                      <h4 className="font-semibold">Chicken Biryani</h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Aromatic rice with tender spiced chicken
                      </p>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">PKR 520</span>
                      <Button size="sm">Add</Button>
                    </div>
                  </div>
                </Card>
                <Card className="shadow-sm rounded-xl overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1541658016709-82535e94bc69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG1pbGtzaGFrZSUyMGRlc3NlcnQlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxMnww&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Mango shake"
                    data-photoid="-xhCOgeoDSs"
                    data-authorname="Fatima Akram"
                    data-authorurl="https://unsplash.com/@fatimaakram"
                    data-blurhash="LgGj{eOD0}tQmkNGOsj?-.XTn%V["
                    className="w-full h-40 object-cover"
                  />
                  <div className="flex p-4 flex-col gap-3">
                    <div className="text-primary text-sm flex items-center gap-1">
                      <Star className="fill-primary size-4" />
                      4.6
                    </div>
                    <div>
                      <h4 className="font-semibold">Mango Shake</h4>
                      <p className="text-muted-foreground text-sm mt-1">
                        Creamy chilled mango freshness
                      </p>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">PKR 380</span>
                      <Button size="sm">Add</Button>
                    </div>
                  </div>
                </Card>
              </div>
            </section>
            <div className="grid gap-6 grid-cols-2">
              <Card className="shadow-sm rounded-xl p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-xl">Special offers</h3>
                    <p className="text-muted-foreground mt-4">
                      Free delivery on orders over PKR 1,500
                    </p>
                  </div>
                  <Truck className="text-primary size-6" />
                </div>
                <Badge className="bg-accent text-accent-foreground mt-6">
                  Use code FREESHIP
                </Badge>
              </Card>
              <Card className="shadow-sm rounded-xl p-6">
                <h3 className="font-bold text-xl">Recent orders</h3>
                <div className="flex mt-4 flex-col gap-3">
                  <div
                    className="border-t-border border-r-border border-b border-b-border border-l-border flex pb-3 justify-between items-center"
                    onClick={() => navigate("/order-tracking")}
                  >
                    <div>
                      <p className="font-mono text-sm">#FH-20841</p>
                      <p className="text-muted-foreground text-xs">12 June</p>
                    </div>
                    <Badge className="bg-accent text-accent-foreground">
                      Preparing
                    </Badge>
                  </div>
                  <div
                    className="border-t-border border-r-border border-b border-b-border border-l-border flex pb-3 justify-between items-center"
                    onClick={() => navigate("/order-tracking")}
                  >
                    <div>
                      <p className="font-mono text-sm">#FH-20798</p>
                      <p className="text-muted-foreground text-xs">10 June</p>
                    </div>
                    <Badge className="bg-primary/10 text-primary">
                      Delivered
                    </Badge>
                  </div>
                  <div
                    className="flex justify-between items-center"
                    onClick={() => navigate("/order-tracking")}
                  >
                    <div>
                      <p className="font-mono text-sm">#FH-20761</p>
                      <p className="text-muted-foreground text-xs">8 June</p>
                    </div>
                    <Badge className="bg-primary/10 text-primary">
                      Delivered
                    </Badge>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
