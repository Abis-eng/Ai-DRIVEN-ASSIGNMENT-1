import { useNavigate } from "react-router-dom";
import {
  Bell,
  CheckCircle,
  ChevronDown,
  CircleHelp,
  LayoutDashboard,
  Minus,
  PackageCheck,
  Plus,
  Search,
  ShoppingCart,
  Sparkles,
  Trash2,
  Utensils,
  UtensilsCrossed,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";

import "./0641a16c-3edd-4d7c-b662-f2e9a512cc5d.css";
import "./Shopping-Cart.screen.css";

export default function ShoppingCart() {
  const navigate = useNavigate();
  return (
    <div data-appearance="light">
      <div className="bg-background text-foreground min-h-screen h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <aside className="bg-sidebar border-y-border border-r border-r-border border-l-border flex fixed z-20 inset-y-0 left-0 px-4 py-6 flex-col w-64">
          <div className="flex px-3 items-center gap-3">
            <div className="rounded-xl bg-primary text-primary-foreground flex justify-center items-center size-10">
              <UtensilsCrossed className="size-5" />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-foreground text-xl tracking-tight">
                FoodHub
              </span>
              <span className="font-semibold uppercase rounded-full bg-accent text-primary text-[10px] tracking-wide px-2 py-0.5">
                AI
              </span>
            </div>
          </div>
          <nav
            aria-label="Main navigation"
            className="flex mt-10 flex-col flex-1 gap-2"
          >
            <a
              href="#dashboard"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/customer-dashboard")}
            >
              <LayoutDashboard className="size-5" />
              <span>Dashboard</span>
            </a>
            <a
              href="#food-menu"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/food-menu")}
            >
              <Utensils className="size-5" />
              <span>Food Menu</span>
            </a>
            <a
              href="#shopping-cart"
              aria-current="page"
              className="font-semibold rounded-xl bg-primary text-primary-foreground text-sm flex px-4 py-3 items-center gap-3"
            >
              <ShoppingCart className="size-5" />
              <span>Shopping Cart</span>
            </a>
            <a
              href="#order-tracking"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/order-tracking")}
            >
              <PackageCheck className="size-5" />
              <span>Order Tracking</span>
            </a>
            <a
              href="#ai-support"
              className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              onClick={() => navigate("/ai-customer-support")}
            >
              <Sparkles className="size-5" />
              <span>AI Support</span>
            </a>
          </nav>
          <a
            href="#help-support"
            className="font-medium rounded-xl text-muted-foreground text-sm flex px-4 py-3 items-center gap-3 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          >
            <CircleHelp className="size-5" />
            <span>{`Help & Support`}</span>
          </a>
        </aside>
        <main className="ml-64 min-h-screen">
          <header className="bg-background border-t-border border-r-border border-b border-b-border border-l-border flex px-8 justify-between items-center h-20">
            <div>
              <p className="text-muted-foreground text-sm">Workspace</p>
              <h1 className="font-bold text-foreground text-2xl tracking-tight">
                Shopping Cart
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                type="button"
                aria-label="Search"
                className="rounded-xl text-muted-foreground flex justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Search className="size-5" />
              </button>
              <button
                type="button"
                aria-label="Notifications"
                className="rounded-xl text-muted-foreground flex relative justify-center items-center size-10 hover:bg-accent hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
              >
                <Bell className="size-5" />
                <span className="rounded-full bg-primary absolute top-2 right-2 size-2" />
              </button>
              <div className="bg-border w-px h-8" />
              <div
                aria-label="Customer account: Ayesha Khan"
                className="flex items-center gap-3"
              >
                <div className="font-semibold rounded-full bg-primary text-primary-foreground text-sm flex justify-center items-center size-10">
                  AK
                </div>
                <div className="text-left hidden md:block">
                  <p className="font-semibold text-foreground text-sm">
                    Ayesha Khan
                  </p>
                  <p className="text-muted-foreground text-xs">Customer</p>
                </div>
                <ChevronDown className="text-muted-foreground size-4" />
              </div>
            </div>
          </header>
          <div className="p-8">
            <div className="mb-8">
              <p className="text-muted-foreground text-sm">
                Home / Shopping Cart
              </p>
              <h2 className="font-bold text-foreground text-3xl tracking-tight mt-2">
                Complete your order
              </h2>
            </div>
            <div className="grid items-start gap-8 grid-cols-3">
              <div className="flex flex-col gap-8 col-span-2">
                <Card className="shadow-sm rounded-xl bg-card border-border">
                  <CardHeader>
                    <CardTitle>Your items</CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col">
                    <div className="border-t-border border-r-border border-b border-b-border border-l-border flex py-4 items-center gap-4">
                      <img
                        src="https://images.unsplash.com/photo-1551782450-a2132b4ba21d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwd2l0aCUyMGZyaWVzJTIwcmVzdGF1cmFudCUyMGZvb2QlMjBwaG90b2dyYXBoeXxlbnwxfDB8fHwxNzkzOTU4OTEzfDA&ixlib=rb-4.1.0&q=80&w=1080"
                        alt="Classic Zinger Burger"
                        data-photoid="uVPV_nV17Tw"
                        data-authorname="sk"
                        data-authorurl="https://unsplash.com/@rollelflex_graphy726"
                        data-blurhash="LD9P}*xs0hRRr?IqSf-m58NJ%K$z"
                        className="rounded-lg size-20 object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground">
                          Classic Zinger Burger
                        </p>
                        <p className="text-muted-foreground text-sm mt-1">
                          Crispy chicken, lettuce, and signature sauce
                        </p>
                        <Badge className="bg-accent text-accent-foreground mt-2">
                          PKR 650
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label="Decrease burger quantity"
                        >
                          <Minus className="size-4" />
                        </Button>
                        <span className="font-semibold text-center text-sm w-6">
                          2
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label="Increase burger quantity"
                        >
                          <Plus className="size-4" />
                        </Button>
                      </div>
                      <p className="font-semibold text-right text-foreground w-24">
                        PKR 1,300
                      </p>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Remove burger"
                      >
                        <Trash2 className="text-muted-foreground size-4" />
                      </Button>
                    </div>
                    <div className="border-t-border border-r-border border-b border-b-border border-l-border flex py-4 items-center gap-4">
                      <img
                        src="https://images.unsplash.com/photo-1611915365928-565c527a0590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxwZXBwZXJvbmklMjBwaXp6YSUyMHNsaWNlZCUyMHJlc3RhdXJhbnQlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxM3ww&ixlib=rb-4.1.0&q=80&w=1080"
                        alt="Pepperoni Pizza"
                        data-photoid="XLmhRnV8yuc"
                        data-authorname="Tamas Pap"
                        data-authorurl="https://unsplash.com/@tamasp"
                        data-blurhash="L9Ra5G^}#Wxsq|Fcwf1z#AS2WCWC"
                        className="rounded-lg size-20 object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground">
                          Pepperoni Pizza
                        </p>
                        <p className="text-muted-foreground text-sm mt-1">
                          Loaded with pepperoni and melted mozzarella
                        </p>
                        <Badge className="bg-accent text-accent-foreground mt-2">
                          PKR 1,450
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label="Decrease pizza quantity"
                        >
                          <Minus className="size-4" />
                        </Button>
                        <span className="font-semibold text-center text-sm w-6">
                          1
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label="Increase pizza quantity"
                        >
                          <Plus className="size-4" />
                        </Button>
                      </div>
                      <p className="font-semibold text-right text-foreground w-24">
                        PKR 1,450
                      </p>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Remove pizza"
                      >
                        <Trash2 className="text-muted-foreground size-4" />
                      </Button>
                    </div>
                    <div className="flex py-4 items-center gap-4">
                      <img
                        src="https://images.unsplash.com/photo-1541658016709-82535e94bc69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG1pbGtzaGFrZSUyMGRlc3NlcnQlMjBmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXwwfHx8MTc5Mzk1ODkxMnww&ixlib=rb-4.1.0&q=80&w=1080"
                        alt="Mango Shake"
                        data-photoid="-xhCOgeoDSs"
                        data-authorname="Fatima Akram"
                        data-authorurl="https://unsplash.com/@fatimaakram"
                        data-blurhash="LgGj{eOD0}tQmkNGOsj?-.XTn%V["
                        className="rounded-lg size-20 object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground">
                          Mango Shake
                        </p>
                        <p className="text-muted-foreground text-sm mt-1">
                          Fresh mango blended with chilled milk
                        </p>
                        <Badge className="bg-accent text-accent-foreground mt-2">
                          PKR 380
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label="Decrease shake quantity"
                        >
                          <Minus className="size-4" />
                        </Button>
                        <span className="font-semibold text-center text-sm w-6">
                          1
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label="Increase shake quantity"
                        >
                          <Plus className="size-4" />
                        </Button>
                      </div>
                      <p className="font-semibold text-right text-foreground w-24">
                        PKR 380
                      </p>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Remove shake"
                      >
                        <Trash2 className="text-muted-foreground size-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                <Card className="shadow-sm rounded-xl bg-card border-border">
                  <CardHeader>
                    <CardTitle>Delivery details</CardTitle>
                  </CardHeader>
                  <CardContent className="grid gap-6 grid-cols-2">
                    <div className="flex flex-col gap-2">
                      <Label htmlFor="name">Full name</Label>
                      <Input id="name" defaultValue="Ayesha Khan" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <Label htmlFor="phone">Phone number</Label>
                      <Input id="phone" defaultValue="+92 300 1234567" />
                    </div>
                    <div className="flex flex-col gap-2 col-span-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" defaultValue="ayesha@example.com" />
                    </div>
                    <div className="flex flex-col gap-2 col-span-2">
                      <Label htmlFor="address">Delivery address</Label>
                      <Textarea
                        id="address"
                        defaultValue="House 24, Street 8, Gulberg III, Lahore"
                      />
                    </div>
                    <div className="flex flex-col gap-4 col-span-2">
                      <Label>Payment method</Label>
                      <RadioGroup defaultValue="cod" className="flex gap-6">
                        <div className="flex items-center gap-2">
                          <RadioGroupItem value="cod" id="cod" />
                          <Label htmlFor="cod">Cash on Delivery</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <RadioGroupItem value="online" id="online" />
                          <Label htmlFor="online">Online Payment</Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="flex sticky top-8 flex-col gap-6">
                <Card className="shadow-sm rounded-xl bg-chart-2/10 border-chart-2 hidden">
                  <CardContent className="text-center flex p-6 flex-col items-center gap-3">
                    <CheckCircle className="text-chart-2 size-12" />
                    <CardTitle>Order confirmed!</CardTitle>
                    <p className="text-muted-foreground text-sm">
                      Your order #FH-20842 is being prepared.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-2"
                      onClick={() => navigate("/order-tracking")}
                    >
                      Track order
                    </Button>
                  </CardContent>
                </Card>
                <Card className="shadow-sm rounded-xl bg-card border-border">
                  <CardHeader>
                    <CardTitle>Order summary</CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-4">
                    <div className="text-sm flex justify-between">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>PKR 3,130</span>
                    </div>
                    <div className="text-sm flex justify-between">
                      <span className="text-muted-foreground">
                        Delivery fee
                      </span>
                      <span>PKR 120</span>
                    </div>
                    <div className="text-sm flex justify-between">
                      <span className="text-muted-foreground">Discount</span>
                      <span className="text-destructive">-PKR 200</span>
                    </div>
                    <div className="border-x-border border-t border-t-border border-b-border" />
                    <div className="font-bold text-lg flex justify-between">
                      <span>Total</span>
                      <span>PKR 3,050</span>
                    </div>
                    <p className="font-medium text-center rounded-lg bg-accent text-accent-foreground text-sm px-3 py-2">
                      You save PKR 200 today
                    </p>
                    <Button className="mt-2 w-full">Place Order</Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
