# Follow-the-instructions-in-the-file

This is a code bundle for Follow-the-instructions-in-the-file. It's based on default Vite project. The original design is available at https://app.flowstep.ai/file?activeFileId=cd2ae55e-0b7b-4ac1-be24-c6ff834c56bb.

## Running the code

Run `npm i` and `npm run setup` to install the dependencies.

Run `npm run dev` to start the development server.
